=======================================================
                                       READ ME * READ ME * READ ME
=======================================================



October 27, 1997

Happy (pre-)Halloween! Just in time to create a few quick holiday
decorations, or to spruce up your notes/memos, comes MonsterParty -- the
latest font from yours truly, Mike Gaines. 36 monsters/images, from the
classic to the modern. Enjoy!

If you'd like to post this font on your site, be my guest; my only
stipulation is that both the Mac & PC fonts are available. (Trying to
promote a little cross-platform tolerance.)

The font is completely FREE, since I do not own the copyright to the
characters used. Please don't use the font to create commercial designs
(since you don't own the character copyrights either, I assume).

For the curious, the artwork was done in Photoshop, converted to
outlines in Illustrator, then imported into Fontographer -- where the
font was generated. The name is an homage to the late 60s animation,
"Mad Monster Party", created by the people who did thos Rankin/Bass
Rudolph animations you still see occasionally at Christmas time. I
encourage you to check it out....

Comments -- or bug reports --  on this or my previous fonts (TNGcast,
Xcast, Herc/Xena) alway welcome....

-- Mike Gaines
    mgaines@proaxis.com
    http://www.proaxis.com/~mgaines (fonts are on 3rd Artwork page)

For those of you who care to know what's available in advance, here's
the mnemonic (a memory trick) chararcter map:

The numbers contain the classics:

0 - Full moon
1 - Drac
2 - Frank
3 - Bride
4 - Wolfie
5 - Mummy
6 - Phantom of the Opera
7 - Creature from the Black Lagoon
8 - King Kong
9 - Godzilla

The rest of the characters are available in the upper case letters:

A - Alien
B - Bela Lagosi
C - Cyclops (Harryhausen)
D - Darkness (Legend)
E - Exorcist (Regan/Linda Blair)
F - Freddy
G - Gary Oldman as Drac
H - Hellraiser's Pinhead
I - Iron Maiden's Eddie
J - Jason
K - Klaus Kinski as Nosferatu
L - Lon Chaney as Hyde
M - Mars Attacks
N - Nicholson (The Shining)
O - Other Vamp (Lon Chaney)
P - Predator
Q - Friday the 13th logo (mentally tilt the art 90 degrees)
R - Re-Animator
S - Scream
T - Tales from the Crypt
U - Miskatonic Univ.
V - Vincent Price
W - Nightbreed Psycho-psychiatrist (doesn't it look like a W?)
X - eXorcist poster art
Y - IT conquered the world (whY does the monster look like a carrot? --
or rotate the
      letter 180 degrees....)
Z - Zombie (Bub from Day of the Dead)